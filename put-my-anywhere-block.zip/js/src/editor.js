// Add the JS code to this file. On running npm run dev, it will compile to js/dist/.

export function add( to, howMuch ) {
	return to + howMuch;
}
