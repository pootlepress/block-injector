<?php
/**
 * Bootstrap PHPUnit related dependencies.
 *
 * @package PutMeAnywhereBlock
 */

WP_Mock::bootstrap();
